class Node:
	def __init__(self,value):
		self.value = value
		self.next = None

class LinkedList:
	def __init__(self):
		self.head = None
		self.tail = None

	def addLast(self, value):		
		if(self.head == None):
			self.head = Node(value)
			self.tail = self.head
		else:
			self.tail.next = Node(value)
			self.tail = self.tail.next
	def first(self):
		return head
	def last(self):
		return tail
	def find(self, value):
		runner = self.head
		while (runner!=None):
			if runner.value == value:
				return runner.value
			else:
				runner = runner.next
		return None



linkedList = LinkedList()
linkedList.addLast(7)
linkedList.addLast(21)
print(linkedList)

head = Node(2)
runner = head
while(runner !=None):
	print(runner.value)
	runner = runner.next

